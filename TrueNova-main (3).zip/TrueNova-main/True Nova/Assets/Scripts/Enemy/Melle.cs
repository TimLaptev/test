using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Melle : MonoBehaviour, IEnemy
{
    [SerializeField] private Animator _animator;
    [SerializeField] private EnemyEntyty _enemyEntyty;
    private const string ATTACK = "Attack";

    public void Attack()
    {
        _animator.SetTrigger(ATTACK);
    }

    public void EnemyAttackON()
    {
        _enemyEntyty.EnemyAttackON();
    }

    public void EnemyAttackOFF()
    {
        _enemyEntyty.EnemyAttackOFF();
    }
}
