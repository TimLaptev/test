using UnityEngine;

[RequireComponent(typeof(EnemyEntyty))]
[RequireComponent(typeof(SpriteRenderer))]
[RequireComponent(typeof(Animator))]

public class SlimeVisual : MonoBehaviour
{
    [SerializeField] private EnemyAi _enemyAi;
    [SerializeField] private EnemyEntyty _enemyEntyty;

    private Animator _animator;

    private const string IS_RUNNING = "IsRoaming";
    private const string CHASING_SPEED_MUTIOLAYER = "ChasingSpeedMultuplyer";
    private const string TAKEHIT = "TakeHit";

    private void Awake()
    {
        _enemyEntyty = GetComponent<EnemyEntyty>();
        _animator = GetComponent<Animator>();
    }

    private void Start()
    {
        _enemyEntyty.OnTakeHit += _enemyEntyty_OnTakeHit;
    }

    private void Update()
    {
        _animator.SetBool(IS_RUNNING, _enemyAi.IsRunning());
        _animator.SetFloat(CHASING_SPEED_MUTIOLAYER, _enemyAi.GetRoamingAnimationSpeed());
    }

    private void OnDestroy()
    {
        _enemyEntyty.OnTakeHit -= _enemyEntyty_OnTakeHit;
    }

    private void _enemyEntyty_OnTakeHit(object sender, System.EventArgs e)
    {
        _animator.SetTrigger(TAKEHIT);
    }
}
