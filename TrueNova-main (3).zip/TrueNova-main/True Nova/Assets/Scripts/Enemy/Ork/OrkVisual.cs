using UnityEngine;


[RequireComponent (typeof(EnemyEntyty))]
[RequireComponent(typeof(SpriteRenderer))]
[RequireComponent(typeof(Animator))]


public class EnemyVisual : MonoBehaviour
{
    [SerializeField] private EnemyAi _enemyAi;
    [SerializeField] private EnemyEntyty _enemyEntyty;
    [SerializeField] private GameObject _enemyShadow;

    SpriteRenderer _spriteRenderer;
    private Animator _animator;

    private const string IS_RUNNONG = "IsRunning";
    private const string CHASING_SPEED_MUTIOLAYER = "ChasingSpeedMultuplyer";
    
    private const string TAKEHIT = "TakeDamage";
    private const string ISDIE = "IsDie";
    private void Awake()
    {
        _enemyEntyty = GetComponent<EnemyEntyty>();
        _animator = GetComponent<Animator>();      
    }

    private void Start()
    {
        _enemyEntyty.OnTakeHit += _enemyEntyty_OnTakeHit;
        //_enemyEntyty.OnDeath += _enemyEntyty_OnDeath;
    }

    private void Update()
    {
        _animator.SetBool(IS_RUNNONG, _enemyAi.IsRunning());
        _animator.SetFloat(CHASING_SPEED_MUTIOLAYER, _enemyAi.GetRoamingAnimationSpeed());
    }

    private void OnDestroy()
    {
        _enemyEntyty.OnTakeHit -= _enemyEntyty_OnTakeHit;
    } 

    private void _enemyEntyty_OnTakeHit(object sender, System.EventArgs e)
    {
        _animator.SetTrigger(TAKEHIT);
    }

    //private void _enemyEntyty_OnDeath(object sender, System.EventArgs e)
    //{
    //    _animator.SetBool(ISDIE, true);
    //    _spriteRenderer.sortingOrder = -1;
    //    _enemyShadow.SetActive(false);
    //}


}
