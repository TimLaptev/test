interface IEnemy
{
    public void Attack();
}