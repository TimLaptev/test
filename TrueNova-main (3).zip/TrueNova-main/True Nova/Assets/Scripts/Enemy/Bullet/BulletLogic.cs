using UnityEngine;

public class BulletLogic : MonoBehaviour
{
    [SerializeField] private int _Damage = 1;
    [SerializeField] private int _moveSpeed = 6;
    [SerializeField] private int _projectileRande = 20;
    private Vector3 _startPosition;

    private void Start()
    {
        _startPosition = transform.position;
    }

    private void Update()
    {
        DetectedFireDistance();
        TargetPlayer();
    }

    private void OnTriggerStay2D(Collider2D collision)//������������ ������ � �������
    {
        if (collision.transform.TryGetComponent(out Player player))
        {
            player.TakeDamage(transform, _Damage);
            Destroy(gameObject);
        }
    }

    private void DetectedFireDistance()
    {
        if (Vector3.Distance(transform.position, _startPosition) > _projectileRande)
        {
            Destroy(gameObject);
        }
    }

    private void TargetPlayer()
    {
        transform.Translate(Vector3.right * Time.deltaTime * _moveSpeed);
    }

}
